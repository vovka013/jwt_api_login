<?php
// объект 'user' 
class User {
 
    // подключение к БД таблице "users" 
    private $conn;
    private $table_name = "users";
 
    // свойства объекта 
    public $id;
    public $firstname;
    public $lastname;
    public $email;
    public $password;
 
    // конструктор класса User 
    public function __construct($db) {
        $this->conn = $db;
    }

  // Проверка, существует ли электронная почта в нашей базе данных 
function emailExists(){
 
    // запрос, чтобы проверить, существует ли электронная почта 
    $query = "SELECT id, firstname, lastname, password
            FROM " . $this->table_name . "
            WHERE email = ?
            LIMIT 0,1";
 
    // подготовка запроса 
    $stmt = $this->conn->prepare( $query );
 
    // инъекция 
    $this->email=htmlspecialchars(strip_tags($this->email));
 
    // привязываем значение e-mail 
    $stmt->bindParam(1, $this->email);
 
    // выполняем запрос 
    $stmt->execute();
 
    // получаем количество строк 
    $num = $stmt->rowCount();
 
    // если электронная почта существует, 
    // присвоим значения свойствам объекта для легкого доступа и использования для php сессий 
    if($num>0) {
 
        // получаем значения 
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
        // присвоим значения свойствам объекта 
        $this->id = $row['id'];
        $this->firstname = $row['firstname'];
        $this->lastname = $row['lastname'];
        $this->password = $row['password'];
 
        // вернём 'true', потому что в базе данных существует электронная почта 
        return true;
    }
 
    // вернём 'false', если адрес электронной почты не существует в базе данных 
    return false;
}
 

}